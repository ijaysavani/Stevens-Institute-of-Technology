// Jay Kalyanbhai Savani

// CWID - 20009207

// Assignment-2 CS 570-B

// Time Complexity
  



 
public class Complexity {
	static int counter = 0;

	
	
	
	
	// Method0: Time Complexity O(n).
	public static void method0(int n) {
		int counter = 0;
		for (int a = 0; a < n; a++) {
			System.out.println("Operation0 " + counter);
			counter++; 
		}
		System.out.println("Time Complexity O(n) : " + counter);

	}
	
	
	
	
	

	// Method1: Time Complexity O(n^2).
	public static void method1(int n) {
		int counter = 0;
		for (int a = 0; a < n; a++) {
			for (int b = 0; b < n; b++) {
				System.out.println("Operation1 " + counter);
				counter++;
			}
		}
		System.out.println("Time Complexity O(n^2) : " + counter);
	}

	
	
	
	
	// Method2: Time Complexity O(n^3)
	public static void method2(int n) {
		int counter = 0;
		for (int a = 0; a < n; a++) {
			for (int b = 0; b < n; b++) {
				for (int c = 0; c < n; c++) {
					System.out.println("Operation2 " + counter);
					counter++; 
				}
			}
		}
		System.out.println("Time Complexity O(n^3) : " + counter);
	}

	
	
	
	
	// Method3: Time Complexity O(log n)
	public static void method3(int n) {
		int counter = 0;
		for (int a = 1; a < n; a = a * 2) {
			System.out.println("Operation3 " + counter);
			counter++;
		}
		System.out.println("Time Complexity O(log n) : " + counter);
	}

	
	
	
	
	// Method4: Time Complexity O(n log n):
	public static void method4(int n) {
		int counter = 0;
		for (int a = 1; a <= n; a++) {
			for (int b = 1; b < n; b = b * 2) {
				System.out.println("Operation4 " + counter);
				counter++;
			}
		}
		System.out.println("Time Complexity O(n log n) : " + counter);
	}
	
	
	
	

	// Method5: Time Complexity O(log log n).
	public static void method5(int n) {
		int counter = 0;
		for (double a = 2; a < n; a = a * a) {
			System.out.println("Operation5 " + counter);
			counter++; 
		}
		System.out.println("Time Complexity O(log log n) : " + counter);
	}

	
	
	
	
	// Method6: Time Complexity O(2^n).
	static int counter6 = 1;
	public static int method6(int n) {

	if(n<=1) {
		counter6++;
		System.out.println("Operation6 " + counter6);
		return n;
		
	}
	
	counter6++;
	System.out.println("Operation6 " + counter6);
	return method6(n-1) + method6(n-1);
	
		
	
	}
	
	
	
	
	

	public static void main(String[] args) {
		System.out.println("\nMethod0 Time Complexity O(n) :");
		method0(5);
		System.out.println("\nMethod1 Time complexity O(n^2) :");
		method1(6);
		System.out.println("\nMethod2 Time complexity O(n^3) :");
		method2(4);
		System.out.println("\nMethod3 Time complexity O(log n) :");
		method3(40);
		System.out.println("\nMethod4 Time complexity O(n log n) :");
		method4(8);
		System.out.println("\nMethod5 Time complexity O(log log n) :");
		method5(250);
		System.out.println("\nMethod6 Time complexity O(2^n) :");
		method6(3);

	}

}
