/*
 * Jay Kalyanbhai Savani
 * Cwid 20009207
 * CS 570B
 * Assignment 6
 */

import java.util.*;
import java.io.*;

/**
 * The Class=Anagrams
 */

public class Anagrams {
	final Integer[] primes = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83,
			89, 97, 101 };

	Map<Character, Integer> letterTable;
	Map<Long, ArrayList<String>> anagramTable;

	/**
	 * With Constructor Anagram Class, init Class variables 
	 * Invoke buildLetterTable 
	 */
	public Anagrams() {
		buildLetterTable();
		anagramTable = new HashMap<Long, ArrayList<String>>();
	}

	/**
	 * Building letters table with hashing by using a to z letters and prime array
	 */
	private void buildLetterTable() {
		letterTable = new HashMap<Character, Integer>();
		Character[] alphabets = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
				'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		for (int i = 0; i < 26; i++)
			letterTable.put(alphabets[i], primes[i]);
	}


	/**
	 * Method hash code for string s pass arguments and add this word hash table to anagramTable.
	 * @param s - Add words string format
	 * @throws IllegalArgumentException
	 */
	private void addWord(String s) throws IllegalArgumentException {
		if (s == null || s.length() == 0)
			throw new IllegalArgumentException();
		Long hashCode = myHashCode(s);
		if (anagramTable.containsKey(hashCode))
			anagramTable.get(hashCode).add(s);
		else {
			ArrayList<String> a = new ArrayList<String>();
			a.add(s);
			anagramTable.put(hashCode, a);
		}
	}

	/**
	 * Calculates & provides hashcode giving to string
	 * @param s  String for which hashcode is calculated
	 * @return hashCode
	 * @throws IllegalArgumentException
	 */
	private Long myHashCode(String s) throws IllegalArgumentException {
		long hashCode = 1;
		try {
			for (int i = 0; i < s.length(); i++)
				hashCode = hashCode * (long) letterTable.get(s.charAt(i));
		} catch (NullPointerException e) {
			throw new IllegalArgumentException("Lowercase letters are allowed in the string");
		}
		return hashCode;
	}

	/**
	 * Processing File Present in Assignment Folder
	 * @param s name of file in string format
	 * @throws IOException
	 */
	private void processFile(String s) throws IOException {
		FileInputStream fStream = new FileInputStream(s);
		BufferedReader br = new BufferedReader(new InputStreamReader(fStream));
		String strLine;
		while ((strLine = br.readLine()) != null) {
			this.addWord(strLine);
		}
		br.close();
	}

	private ArrayList<Map.Entry<Long, ArrayList<String>>> getMaxEntries() {
		ArrayList<Map.Entry<Long, ArrayList<String>>> lists = new ArrayList<>();
		int max = 0;
		for (Map.Entry<Long, ArrayList<String>> entry : anagramTable.entrySet()) {
			if (entry.getValue().size() > max) {
				lists.clear();
				lists.add(entry);
				max = entry.getValue().size();
			} else if (entry.getValue().size() == max)
				lists.add(entry);
		}
		return lists;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Anagrams a = new Anagrams();
		final long startTime = System.nanoTime();
		try {
			a.processFile("words_alpha.txt");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ArrayList<Map.Entry<Long, ArrayList<String>>> maxEntries = a.getMaxEntries();
		long hashCode = maxEntries.get(0).getKey();
		int length = maxEntries.get(0).getValue().size();
		final long estimatedTime = System.nanoTime() - startTime;
		final double seconds = ((double) estimatedTime / 1000000000);
		System.out.println("Time Elapsed : " + seconds);
		System.out.println("Max Anagrams Key : " + hashCode);
		System.out.println("Max Anagrams List : " + maxEntries.get(0).getValue());
		System.out.println("Max Anagrams Length of List : " + length);
	}
}
