/*
 * Jay Kalyanbhai Savani
 * CS 570B
 * Cwid- 20009207
 * Assignment 1 = Binary Number
 */




import java.util.Arrays;

public class BinaryNumber {
	
	//Object Type Array
	private int data[]; 
	private boolean overflow;
	
	//Binary Number of Length
	public BinaryNumber(int length){
	// Initialize with Length
	data= new int[length];  
	for(int j=0; j<length;j++) {
		data[j]=0;
	}
	
	}
	//Creating a Binary Number String
	public BinaryNumber(String str){
		int length=str.length();
		//Length of this String
		data= new int[length];
		for(int j=0; j<length; j++) {
			if(Character.getNumericValue(str.charAt(j))==1 || Character.getNumericValue(str.charAt(j))==0) {
				
				data[j]= Character.getNumericValue(str.charAt(j));
			} 
			else {System.out.println("Input Number is not the Binary");}
			
		}
		
	
	}
	
	//The Length of Binary Number
	public int getLength() {
			return data.length;
			
		}
	
	//Digit of a Binary Number Given an index
	public int getDigit(int index) {
		
		if(index>data.length) {
			System.out.println("The Index is out of the Bounds");
			System.exit(1);
			return 0;
		} 
		else {
				return data[index];}
		}
	
	//Binary Number to its Decimal Notation
	public int toDecimal() {
		int decimal = 0;int a = 0;int b = 0;
		 ;
		 for(int j=0; j<data.length; j++) {	
			 b = data[j];
			 decimal = (int) (decimal + b * Math.pow(2,a));
			a++;
		 }
		 return decimal;
		 
	 }
	
	public void shiftR(int amount) {
		
		data = Arrays.copyOf(data,(data.length + amount));
		int z = data.length;
		for(int c=0; c<amount; c++) {
			int temp = data[z-1];
			for(int j=z-1; j>0; j--) {
				data[j] = data[j-1];
			}
			data[0] = temp;
			}
	}
	
	//Add Two Binary Numbers.
		public void add(BinaryNumber cBinaryNumber) {
			int data1[] = new int[cBinaryNumber.getLength()];
			data1 = cBinaryNumber.getBinary();
			int carry = 0;
			if(data.length == data1.length) {
				for(int j=0; j<data.length; j++) {
					int t = (carry + data[j] + data1[j]);
					if(t == 0) {
						data[j] = 0;
						carry = 0;
					} else if(t == 1) {
						data[j] = 1;
						carry = 0;
					} else if(t == 2) {
						data[j] = 0;
						carry = 1;
					} else if(t == 3) {
						data[j] = 1;
						carry = 1;
					}
				}
				if(carry == 1) {
					overflow = true;				
				}
			}
			else {
				System.out.println("The lengths of the binary numbers occur the same time");
			}
		}
		
		private int[] getBinary() {
			return data;
		}
		
		//Binary Number to a String.
		public String toString(){
			if(overflow) {
				return "overflow";
			}
			else {
				for (int j=0; j<data.length; j++) {
	        	System.out.print(data[j]);
	        }
			return ".";
			}
		}
		public void clearOverflow() {
			overflow = false;
		}
		

	public static void main(String[] args) {
		
		BinaryNumber BN1 = new BinaryNumber(7);
		BinaryNumber BN2 = new BinaryNumber("1011011");
		
		BN1.toString();
		System.out.println();
		System.out.println(BN2.getLength());
		System.out.println(BN2.getDigit(3));
		BN1.add(BN2);
		System.out.println(BN1.toString());
		System.out.println(BN2.toDecimal());
	}
		
	}