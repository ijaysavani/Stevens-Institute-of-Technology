import java.util.Random;
import java.util.Stack;




/**
 * 
 * @author Jay Kalyanbhai Savani
 * CWID:- 20009207
 * @param <E>
 */




public class Treap<E extends Comparable<E>>{
	
	
	private static class Node<E>{
		public E data; 
		public int priority; 
		public Node<E> left;
		public Node<E> right;
		
		/**
		 * Creating Constructor
		 * @param data as KEY stored in data for sorting 
		 * @param priority Creation of heap
		 */
		public Node(E data , int priority){
		if(data==null) {
				throw new IllegalArgumentException();
				}
			else
			
		
		{
			this.left = this.right = null;
			this.priority = priority;
			this.data = data;
		}}
	
		/**
		 * Method Performing Right Rotation
		 * @return ROOT NODE=Result Tree
		 */
		Node<E> rotateRight()
		{
			Node<E> LeftAfterRotation = this.left.right;
			Node<E> rootAfter = this.left;
			rootAfter.right = this;
			this.left = LeftAfterRotation;
			return rootAfter;
			
		}

		/**
		 * Method Performing Left Rotation
		 * @return ROOT NODE=Result Tree
		 */
		Node<E> rotateLeft()
		{
			Node<E> RightAfterRotation = this.right.left;
			Node<E> rootAfter = this.right;
			rootAfter.left = this;
			this.right = RightAfterRotation;
			return rootAfter;
		}
		
		public String toString()
		{
			return new String("(Key=" + data + ", Priority = "+priority + ")");
		}
	}
	
	private Random priorityGenerator;
	private Node <E> root;
	// Create Empty Treap With Constructor
	public Treap()
	{
		root = null;
		this.priorityGenerator = new Random();
	}
	
	/**
	 * Constructor Parameter Initialize Priority Generator 
	 * @param seed
	 */
	public Treap(long seed)
	{
		root = null;
		this.priorityGenerator = new Random(seed);
	}

	private void reheap(Stack<Node<E>> heap,Node<E> newAdded)
	{
		Node<E> child = newAdded;
		while(!heap.empty())
		{
			Node<E> parent = heap.pop();
			if(parent.priority>child.priority)
				return;
			if(child.data.compareTo(parent.data)<0)
				child = parent.rotateRight();
			else if(child.data.compareTo(parent.data)>0)
				child = parent.rotateLeft();
			if(heap.isEmpty())
				root = child;
			else if(heap.peek().left!=null && heap.peek().left.data.compareTo(parent.data)==0)
				heap.peek().left = child;
			else
				heap.peek().right = child;
		}
	}
	
	//Method Create
	
	public boolean add(E key) throws IllegalArgumentException
	{	
		return this.add(key,priorityGenerator.nextInt(1000));	
	}
	
	public boolean add(E key , int priority) throws IllegalArgumentException
	{
		if(key == null)
			throw new IllegalArgumentException("Data Provided is Null");
		Node<E> newNode = new Node<E>(key,priority);
		Stack<Node<E>> visited = new Stack<Node<E>>();
		Node<E> parent = root;
		if(root==null)
		{
			root = newNode;
			return true;
		}
		while(true)
		{
			int goLeft = key.compareTo(parent.data);
			if(goLeft<0)
			{
				visited.push(parent);
				if(parent.left != null)
					parent = parent.left;
				else
					break;
			}
			else if(goLeft > 0)
			{
				visited.push(parent);
				if(parent.right != null)
					parent = parent.right;
				else
					break;
			}
			else 
				return false;
		}
		if(parent.data.compareTo(key)<0)
			parent.right = newNode;
		else
			parent.left = newNode;
		reheap(visited,newNode);
		return true;
	}
	/**
	 * Deletion Node key Treap and Return True or else False
	 * @param key
	 * @return
	 * @throws IllegalArgumentException
	 */
	public boolean delete(E key) throws IllegalArgumentException
	{
		if(key == null)
			throw new IllegalArgumentException("Data Provided is Null");
		if(root==null)
			return false;
		Node<E> localRoot = root;
		Node<E> parent = root;
		boolean isLeft = false;
		while(true)
		{
			int goLeft = key.compareTo(localRoot.data);
			if(goLeft<0)
			{
				if(localRoot.left == null)
					return false;
				parent = localRoot;
				localRoot = localRoot.left;
			}
			else if(goLeft > 0)
			{
				if(localRoot.right==null)
					return false;
				parent = localRoot;
				localRoot = localRoot.right;
			}
			else
			{
				break;
			}
		}
		boolean isRoot = false;
		if(localRoot == root)
		{
			isRoot = true;
			if(root.left == null && root.right == null)
			{	
				root = null;
				return true;
			}
		}
		else if(parent.left!=null)
			if(parent.left.data.compareTo(localRoot.data)==0)
				isLeft = true;
		while(localRoot.left!=null || localRoot.right!=null)
		{
			if(localRoot.right==null)
			{
				localRoot = localRoot.rotateRight();
				if(!isRoot)
				{
					if(isLeft)
						parent.left = localRoot;
					else
						parent.right = localRoot;
				}
				else
				{
					root = localRoot;
					isRoot = false;
				}
				isLeft= false;
				parent = localRoot;
				localRoot = localRoot.right;
			}
			else if(localRoot.left == null)
			{
				localRoot = localRoot.rotateLeft();
				if(!isRoot)
				{
					if(isLeft)
					parent.left = localRoot;
					else
						parent.right = localRoot;
				}
				else 
				{
					root = localRoot;
					isRoot = false;
				}
				isLeft = true;
				parent = localRoot;
				localRoot = localRoot.left;
			}
			else
			{
				if(localRoot.right.priority > localRoot.left.priority)
				{
					
					localRoot = localRoot.rotateLeft();
					if(!isRoot)
					{
						if(isLeft)
							parent.left = localRoot;
						else
							parent.right = localRoot;
					}
					else 
					{
						root = localRoot;
						isRoot = false;
					}
					isLeft = true;
					parent = localRoot;
					localRoot = localRoot.left;
				}
				else
				{
					
					localRoot = localRoot.rotateRight();
					if(!isRoot)
					{
						if(isLeft)
							parent.left = localRoot;
						else
							parent.right = localRoot;
					}
					else
					{
						root = localRoot;
						isRoot = false;
					}
					isLeft= false;
					parent = localRoot;
					localRoot = localRoot.right;
				}
			}
		}
		if(parent.right==localRoot)
			parent.right = null;
		else if(parent.left == localRoot)
			parent.left = null;
		localRoot = null;
		return true;
	}
	
	/**
	 * Searching Node KEY Treap Rooted
	 * @param root
	 * @param key
	 * @return
	 * @throws IllegalArgumentException
	 */
	private boolean find(Node <E> root , E key ) throws IllegalArgumentException
	{
		if(key==null)
			throw new IllegalArgumentException("Element Cannot be Null");
		if(this.root == null)
			return false;
		Node<E> localRoot = root;
		while(true)
		{
			int goLeft = key.compareTo(localRoot.data);
			if(goLeft<0)
			{
				if(localRoot.left == null)
					return false;
				localRoot = localRoot.left;
			}
			else if(goLeft > 0)
			{
				if(localRoot.right==null)
					return false;
				localRoot = localRoot.right;
			}
			else
			{
				return true;
			}
		}
	}
	
	public boolean find(E key) throws IllegalArgumentException
	{
		return this.find(this.root,key);
	}

	public String toString()
	{
		StringBuffer s = new StringBuffer();
		toString(root,0,s);
		return s.toString();
	}

	private void toString(Node<E> node, int spaces, StringBuffer sb)
	{
		for(int j=0;j<spaces;j++)
			sb.append("  ");
		if(node==null)
			sb.append("null\n");
		else
		{
			sb.append(node);
			sb.append("\n");
			toString(node.left,spaces+1,sb);
			toString(node.right,spaces+1,sb);
		}
	}
	
	
	public static void main(String[] args) throws IllegalArgumentException{
		// Auto Generation METHOD=STUB
		Treap<Integer> testTree = new Treap < Integer >();
		// Testing add elements
		testTree.add (4 ,19);
		testTree.add (2 ,31);
		testTree.add (6 ,70);
		testTree.add (1 ,84);
		testTree.add (3 ,12);
		testTree.add (5 ,83);
		testTree.add (7 ,26);
		System.out.println(testTree);
	}

}
