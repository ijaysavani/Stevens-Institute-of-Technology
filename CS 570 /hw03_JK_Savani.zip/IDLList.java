/* NAME : JAY KALYANBHAI SAVANI
 * CWID : 20009207
 * HW   : ASSIGNMENT 3 LISTS
 * CLASS: CS 570 B
 */
package IDLList;
import java.util.ArrayList;
public class IDLList<E> {

	// NODE : DECLARING INNER CLASS <E>
	private static class Node<E>{
	// NODE : PRIVATE INNER CLASS<E>	
		E data;
		Node<E> next;
		Node<E> prev;
	// ELEMENT : THE CONSTRUCTOR CREATES NODE 	
		Node(E elem) {
			this.data = elem;
		}
	// ELEMENT : CONSTRUCTOR CREATES ELEM, NEXT AND PREV		
		Node(E elem, Node<E> prev, Node<E> next) {
			this.data = elem;
			this.prev = prev;
			this.next = next;
		}
	}
	
	
	
	// IDLLIST<E> : THIS CLASS HAS DECLARATION INNER PRIVATE CLASS OF NODE<E>
	// IT HAS 4 DIFFERENT DATA FIELDS
	private Node<E> head;
	private Node<E> tail;
	private int size;
	private ArrayList<Node<E>> indices;
	public IDLList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
		this.indices = new ArrayList<Node<E>>();		
	}
	// ELEMENT : ADDING THIS POSITION TO THE INDEX
		public boolean add(int index, E elem) throws IndexOutOfBoundsException {
			if (index < 0 || index > size)
				throw new IndexOutOfBoundsException();
			if (index == 0)
				add(elem);
			else if (index == size)
				append(elem);
			else {
				Node<E> a = indices.get(index);
				Node<E> nde = new Node<E>(elem, a.prev, a);
				a.prev.next = nde;
				a.prev = nde;
				indices.add(index, nde);
				size++;
			}
			return true;
			}
	//ELEMENT : ADDING ON THE HEAD
		public boolean add(E elem) {
			if (size == 0) {
				Node<E> nde = new Node<E>(elem);
				head = nde;
				tail = nde;
				indices.add(nde);
			} else {
				Node<E> nde = new Node<E>(elem, null, head);
				head.prev = nde;
				head = nde;
				indices.add(0, nde);
			}
			size++;
			return true;
		}
	//ELEMENT : ADDING AS NEW IN LIST
		public boolean append(E elem) {
			if (size == 0) {
				Node<E> nde = new Node<E>(elem);
				head = nde;
				tail = nde;
				indices.add(nde);
			} else {
				Node<E> nde = new Node<E>(elem, tail, null);
				tail.next = nde;
				tail = nde;
				indices.add(nde);
			}
			size++;
			return true;
		}
	// POSITION OF INDEX FROM THE HEAD RETURNS
		public E get(int index) {
			return indices.get(index).data;
		}
	// OBJECT AT THE HEAD RETURNS
		public E getHead() {
			return head.data;
		}
	//OBJECT AT THE TAIL RETURNS	
		public E getLast() {
			return tail.data;
		}
	//LIST SIZE RETURNS
		public int size() {
			return indices.size();
		}
	// ELEMENT IN THE HEAD IS BEEN REMOVE AND RETURN
		public E remove() throws IndexOutOfBoundsException {
			E elementremove;
			if (size == 0)
				throw new IndexOutOfBoundsException("Empty List Cannot Be Removed!");
			else if (size == 1) {
				elementremove = head.data;
				head = null;
				tail = null;
			} else {
				elementremove = head.data;
				head.next.prev = null;
				head = head.next;
			}
			indices.remove(0);
			size--;
			return elementremove;
		}
	//ELEMENTS AT THE TAIL IS BEEN REMOVE AND RETURN
		public E removeLast() throws IndexOutOfBoundsException {
			E RemoveLast;
			if (size == 0)
				throw new IndexOutOfBoundsException("Empty List Cannot Be Removed!");
			else if (size == 1) {
				RemoveLast = tail.data;
				head = null;
				tail = null;
			} else {
				RemoveLast = tail.data;
				tail.prev.next = null;
				tail = tail.prev;
			}
			indices.remove(size - 1);
			size--;
			return RemoveLast;
		}
	// ELEMENT AT INDEX REMOVES AND RETURNS
		public E removeAt(int index) throws IndexOutOfBoundsException {
			E RemoveAt;
			if (index < 0 || index >= size)
				throw new IndexOutOfBoundsException();
			if (size == 1) {
				RemoveAt = head.data;
				head = null;
				tail = null;
			} else if (index == 0) {
				RemoveAt = head.data;
				head.next.prev = null;
				head = head.next;
			}

			else if (index == size - 1) {
				RemoveAt = tail.data;
				tail.prev.next = null;
				tail = tail.prev;
			} else {
				Node<E>a = indices.get(index);
				RemoveAt = a.data;
				a.prev.next = a.next;
				a.next.prev = a.prev;
			}
			indices.remove(index);
			size--;
			return RemoveAt;
		}
	//REMOVE FIRST ELEMENT ON LIST, RETURN TRUE OR FALSE IF IT IS NO IN LIST
		public boolean remove(E elem) {
			for (int j = 0; j < indices.size(); j++) {
				if (indices.get(j).data == elem) {
					removeAt(j);
					return true;
				}
			}
			return false;
		}
	// LIST : STRING REPRESENTATION
		public String toString() {
			String str = "";
			for (int j = 0; j < size; j++) {
				if (j != size - 1)
					str = str + (indices.get(j).data + ", ");
				else
					str = str + (indices.get(j).data);
			}
			str += "";
			return str;
		}

	}


