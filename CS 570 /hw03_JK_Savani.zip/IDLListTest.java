/* Jay Kalyanbhai Savani
 * 20009207
 * Assignment 3 lists Test Case
 * CS 570 B
 */
package IDLList;
public class IDLListTest {
	// TODO Auto-generated constructor stub
	public static void main(String[] args) {
		IDLList<Integer> IDLLIST = new IDLList<Integer>();
        IDLLIST.add(6);
        System.out.println("List Of The First Element SIX : " + IDLLIST.toString());
        IDLLIST.add(0, 5);
        System.out.println("List After Adding FIVE At The Head : " + IDLLIST.toString());
        IDLLIST.add(2, 7);
        System.out.println("List After Adding SEVEN At Second Index : " + IDLLIST.toString());
        IDLLIST.append(8);
        System.out.println("List After Appending EIGHT : " + IDLLIST.toString());        
        System.out.println("Element On First INDEX Position : " + IDLLIST.get(1));        
        System.out.println("Head : " + IDLLIST.getHead());        
        System.out.println("Tail : " + IDLLIST.getLast());
        System.out.println("Size : " + IDLLIST.size());       
        System.out.println("Remove Head Element : " + IDLLIST.remove());
        System.out.println("After Remove, Updated List : " + IDLLIST.toString());
        System.out.println("Remove Tail Element : " + IDLLIST.removeLast());
        System.out.println("After Remove, Updated List : " + IDLLIST.toString());
        IDLLIST.append(9);
        IDLLIST.add(2, 9);
        System.out.println("Updated List Appending NINE Twice, List Is : " + IDLLIST.toString());
        IDLLIST.remove(9);
        System.out.println("Final List After Removing First Occurrence of NINE : " + IDLLIST.toString());
	}
}
